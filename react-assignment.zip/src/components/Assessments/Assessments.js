import React, { useEffect, useState } from "react";
import { Container, Alert } from 'react-bootstrap';
import ODAS from "../../api/odas";
import CardUI from "../cards";
import './Assessments.css';

const Assessments = () => {

  const [assessments, setAssements] = useState([]);
  const [isShowAlert, showAlert] = useState(false);
  const [alertTile, setAlertTitle] = useState('');

  useEffect(() => {
    getData({ public: true });
  }, []);

  const getData = async (params) => {
    const data = await ODAS.get(params);
    setAssements(data.assessments);
  }

  const setAlertData = (data) => {
    showAlert(true);
    setAlertTitle(data);
  }

  return (
    <Container className="container-width">
       {isShowAlert && <AlertUI alertHide={showAlert} title={alertTile}/>}
      <span>AVAILABLE</span>
      {assessments.length && assessments.map(item => (
        <CardUI setAlertData={setAlertData} key={item.title} data={item} />
      ))}
      

    </Container>
  )
};

const AlertUI = (props) => {
  return (
    <Alert dismissible onClose={() => props.alertHide(false)} variant="light">
      {props.title}
    </Alert>
  )
}

export default Assessments;