import React, { useState } from "react";
import "./cards.css"
import { Card, Button, Alert } from 'react-bootstrap';

const CardUI = (props) => {

    return (
        <>
         <Card>
            <Card.Body className="card-body-style">
                <div style={{ flex: 6 }}>
                    <Card.Text >
                        <span className="card-title-style">{props.data.title}</span>
                        <br />
                        <span className="card-text-style">{props.data.author}</span>
                    </Card.Text>
                </div>
                <div style={{ flex: 2 }} className="btn-container-style">
                    <Button onClick={() => props.setAlertData(props.data.title)} className="btn-style" variant="primary">Get Started
                        <i className="arrow right"></i>
                    </Button>
                </div>
            </Card.Body>
        </Card >
       
        </>
       
    )
}

export default CardUI;
